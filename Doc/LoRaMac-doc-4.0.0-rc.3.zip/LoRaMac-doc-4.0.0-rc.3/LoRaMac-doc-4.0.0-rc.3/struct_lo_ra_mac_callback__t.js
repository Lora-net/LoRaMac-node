var struct_lo_ra_mac_callback__t =
[
    [ "MeasureBatteryLevel", "struct_lo_ra_mac_callback__t.html#a7cbc774ca34775b99d6ce6ffe3940345", null ]
];