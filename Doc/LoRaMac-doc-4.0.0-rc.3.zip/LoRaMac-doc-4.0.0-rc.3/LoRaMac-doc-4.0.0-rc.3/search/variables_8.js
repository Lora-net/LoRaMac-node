var searchData=
[
  ['lasttxdonetime',['LastTxDoneTime',['../group___l_o_r_a_m_a_c.html#a9d5374396f5616445e8dd171fde33def',1,'Band_t']]]
];
