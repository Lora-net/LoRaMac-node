var indexSectionsWithContent =
{
  0: "abcdefijlmnprstuv",
  1: "bcdlmrsu",
  2: "l",
  3: "l",
  4: "abcdefijlmnprstuv",
  5: "dlm",
  6: "bcflms",
  7: "l",
  8: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules",
  8: "Pages"
};

