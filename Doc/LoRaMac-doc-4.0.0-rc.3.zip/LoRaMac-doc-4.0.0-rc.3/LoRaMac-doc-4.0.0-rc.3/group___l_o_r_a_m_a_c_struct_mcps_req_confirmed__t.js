var group___l_o_r_a_m_a_c_struct_mcps_req_confirmed__t =
[
    [ "fBuffer", "group___l_o_r_a_m_a_c.html#a2e9f11cf5a8f2a797999359bedee31af", null ],
    [ "fBufferSize", "group___l_o_r_a_m_a_c.html#a6b4fc83528d7391a193516d9f4ba985b", null ],
    [ "fPort", "group___l_o_r_a_m_a_c.html#a2973de9ac0ab5e876b80362bc4c6a88b", null ],
    [ "nbRetries", "group___l_o_r_a_m_a_c.html#a587c816d3c5fd1b12d22fefebca04c27", null ]
];