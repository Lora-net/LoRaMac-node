var group___l_o_r_a_m_a_c_struct_rx2_channel_params__t =
[
    [ "Datarate", "group___l_o_r_a_m_a_c.html#a780280c12645b2666878162aab5d8cad", null ],
    [ "Frequency", "group___l_o_r_a_m_a_c.html#ade3d190636488dad9a89b19446b7acf1", null ]
];