var group___l_o_r_a_m_a_c_union_lo_ra_mac_frame_ctrl__t =
[
    [ "Bits", "group___l_o_r_a_m_a_c.html#afa5183f79607a88f8c9b7daf33216656", null ],
    [ "Value", "group___l_o_r_a_m_a_c.html#a88f4d00bdab99ae6f48c7ae0bc468bb4", null ]
];