var group___l_o_r_a_m_a_c_struct_band__t =
[
    [ "DCycle", "group___l_o_r_a_m_a_c.html#a9ab2dfbcbe5e7e43c95ff6a436886139", null ],
    [ "LastTxDoneTime", "group___l_o_r_a_m_a_c.html#a9d5374396f5616445e8dd171fde33def", null ],
    [ "TimeOff", "group___l_o_r_a_m_a_c.html#a3c5e6b48be6b6561ce9b17cc5e64db09", null ],
    [ "TxMaxPower", "group___l_o_r_a_m_a_c.html#a1b9d27384fedab3a94167b8e9bf9b432", null ]
];