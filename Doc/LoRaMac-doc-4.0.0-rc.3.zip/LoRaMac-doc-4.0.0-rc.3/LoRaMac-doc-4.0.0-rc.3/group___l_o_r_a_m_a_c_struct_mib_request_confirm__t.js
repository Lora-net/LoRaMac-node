var group___l_o_r_a_m_a_c_struct_mib_request_confirm__t =
[
    [ "Param", "group___l_o_r_a_m_a_c.html#afb8c77b3200d879d36beed691fb71f8d", null ],
    [ "Type", "group___l_o_r_a_m_a_c.html#ada1f9249fb28125c69bdfacfaeeae0e2", null ]
];