var group___l_o_r_a_m_a_c_struct_mcps_req__t =
[
    [ "Req", "group___l_o_r_a_m_a_c.html#abefc0ad64bd2753c8fd383c6716cbd79", null ],
    [ "Type", "group___l_o_r_a_m_a_c.html#a29993a5d65888bf0f36ec406896bb540", null ]
];