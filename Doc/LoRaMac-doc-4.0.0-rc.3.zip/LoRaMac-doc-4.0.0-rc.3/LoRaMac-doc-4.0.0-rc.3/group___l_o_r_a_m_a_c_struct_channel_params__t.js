var group___l_o_r_a_m_a_c_struct_channel_params__t =
[
    [ "Band", "group___l_o_r_a_m_a_c.html#a724c03aa06953111c3291243831f251b", null ],
    [ "DrRange", "group___l_o_r_a_m_a_c.html#ad4d9b041ea740886a05fa8a1d06997a2", null ],
    [ "Frequency", "group___l_o_r_a_m_a_c.html#ade3d190636488dad9a89b19446b7acf1", null ]
];